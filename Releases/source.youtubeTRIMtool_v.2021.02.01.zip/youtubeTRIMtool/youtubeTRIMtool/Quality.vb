﻿Public Class Quality

    Private Sub Quality_SizeChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.SizeChanged
        '########################################################################################
        '####################   Change size of Textbox on window size change ####################
        '########################################################################################
        TextBox1.Height = ClientSize.Height
        TextBox1.Width = ClientSize.Width
    End Sub
    Private Sub Quality_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        '########################################################################################
        '##############################   Change size of Textbox  ###############################
        '########################################################################################
        TextBox1.Height = ClientSize.Height
        TextBox1.Width = ClientSize.Width

        '########################################################################################
        '################################   Restart Checkbox  ###################################
        '########################################################################################

        If Form1.ComboBox2.SelectedItem = "bestvideo+bestaudio" Then   'best video quality
            Form1.ComboBox2.Items.Clear()
            Form1.ComboBox2.Items.Add("bestvideo+bestaudio")
            Form1.ComboBox2.SelectedItem = "bestvideo+bestaudio"
        ElseIf Form1.ComboBox2.SelectedItem = "bestaudio" Then          'best audio quality
            Form1.ComboBox2.Items.Clear()
            Form1.ComboBox2.Items.Add("bestaudio")
            Form1.ComboBox2.SelectedItem = "bestaudio"
        ElseIf Form1.ComboBox2.SelectedItem = "best" Then               'best live stream quality
            Form1.ComboBox2.Items.Clear()
            Form1.ComboBox2.Items.Add("best")
            Form1.ComboBox2.SelectedItem = "best"
        End If

        '########################################################################################
        '################################   Create cmd-command  #################################
        '########################################################################################

        TextBox1.Text = "Please wait!" & vbCrLf & "--------------------------------------------------------------------" & vbCrLf
        TextBox1.SelectionStart = TextBox1.Text.Length
        TextBox1.Refresh()

        Video_Quality_Process = New Process

        With Video_Quality_Process.StartInfo
            .FileName = "cmd"
            .RedirectStandardError = True
            .RedirectStandardInput = True
            .RedirectStandardOutput = True
            .CreateNoWindow = True
            .UseShellExecute = False
        End With

        Video_Quality_Process.Start()
        Video_Quality_Process.StandardInput.WriteLine("chcp 1251")
        Video_Quality_Process.StandardInput.WriteLine("cls")
        Video_Quality_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
        Video_Quality_Process.StandardInput.WriteLine("youtube-dl -F " & Form1.TextBox1.Text & " && taskkill /im cmd.exe /t /f")

        Video_Quality_Process.BeginErrorReadLine()
        Video_Quality_Process.BeginOutputReadLine()

    End Sub

    Private Sub p_OutputDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Video_Quality_Process.OutputDataReceived
        On Error Resume Next
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub p_ErrorDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Video_Quality_Process.ErrorDataReceived
        On Error Resume Next
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub Write(ByVal Line As String)

        Dim temp As String = ""

        '########################################################################################
        '##################################   audio qualities  ##################################
        '########################################################################################

        If Form1.ComboBox2.SelectedItem = "bestaudio" Then

            If Line.Contains("resolution") Or Line.Contains("audio only") Then

                TextBox1.Text &= Line

                If Line.Contains("audio only") Then
                    temp = (Line.Substring(0, 5))
                    temp = temp.Replace(" ", "")
                    Form1.ComboBox2.Items.Add(temp)
                End If

            End If

        ElseIf Form1.ComboBox2.SelectedItem = "bestvideo+bestaudio" Then

            '########################################################################################
            '##################################   video qualities  ##################################
            '########################################################################################

            If Line.Contains("resolution") Or Line.Contains("vp9") Or Line.Contains("avc1") Or Line.Contains("av01") Then

                TextBox1.Text &= Line

                If Line.Contains("vp9") Or Line.Contains("avc1") Or Line.Contains("av01") Then
                    temp = (Line.Substring(0, 5))
                    temp = temp.Replace(" ", "")
                    Form1.ComboBox2.Items.Add(temp)
                    Form1.ComboBox2.Items.Add(temp & "+bestaudio")
                End If

            End If


        ElseIf Form1.ComboBox2.SelectedItem = "best" Then
            '########################################################################################
            '##############################   live-stream qualities  ################################
            '########################################################################################

            If Line.Contains("resolution") Or Line.Contains("mp4") Then

                TextBox1.Text &= Line

                If Line.Contains("mp4") Or Line.Contains("HLS") Then
                    temp = (Line.Substring(0, 5))
                    temp = temp.Replace(" ", "")
                    Form1.ComboBox2.Items.Add(temp)
                End If

            End If

        End If

    End Sub

    Private WithEvents Video_Quality_Process As Process
    Private Delegate Sub WriteA(ByVal Text As String)

End Class