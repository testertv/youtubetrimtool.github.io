﻿Imports System.Runtime.InteropServices
Imports System.IO                                   'options file
Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        '########################################################################################
        '##########################   Get start time from URL-link  #############################
        '########################################################################################
        On Error GoTo errorhandler

        If TextBox1.Text.Contains("youtu.be") Then
            '--- convert link to time ---
            Dim Start_Time_Link As Integer = TextBox1.Text.Replace(Strings.Left(TextBox1.Text, InStr(TextBox1.Text, "=")), "")  'extract yotube time
            Dim Start_Time_in_Hours As Integer = Fix(Start_Time_Link / 3600)
            Dim Start_time_in_Minutes As Integer = Fix((Start_Time_Link - (3600 * Start_Time_in_Hours)) / 60)
            Dim Start_time_in_Secondes As Integer = Start_Time_Link - (Start_time_in_Minutes * 60 + Start_Time_in_Hours * 3600)

            NumericUpDown1.Value = Start_Time_in_Hours
            NumericUpDown2.Value = Start_time_in_Minutes
            NumericUpDown3.Value = Start_time_in_Secondes
        Else
            MsgBox("Please insert youtube-link with the point of time:" & vbCrLf & "        Example: https://youtu.be/id?t=00000")
        End If

errorhandler:
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        '########################################################################################
        '##########################   Get end time from URL-link    #############################
        '########################################################################################

        On Error GoTo errorhandler

        If TextBox1.Text.Contains("youtu.be") Then
            Dim Start_Time_Link As Integer = TextBox1.Text.Replace(Strings.Left(TextBox1.Text, InStr(TextBox1.Text, "=")), "")  'extract yotube time
            Dim Start_Time_in_Hours As Integer = Fix(Start_Time_Link / 3600)
            Dim Start_time_in_Minutes As Integer = Fix((Start_Time_Link - (3600 * Start_Time_in_Hours)) / 60)
            Dim Start_time_in_Secondes As Integer = Start_Time_Link - (Start_time_in_Minutes * 60 + Start_Time_in_Hours * 3600)

            NumericUpDown6.Value = Start_Time_in_Hours
            NumericUpDown5.Value = Start_time_in_Minutes
            NumericUpDown4.Value = Start_time_in_Secondes
        Else
            MsgBox("Please insert youtube-link with the point of time:" & vbCrLf & "        Example: https://youtu.be/id?t=00000")
        End If

errorhandler:
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        '########################################################################################
        '###################################  (Un)pin window  ###################################
        '########################################################################################

        If Me.TopMost = True Then
            Me.TopMost = False
            Button5.BackColor = System.Drawing.SystemColors.Control
        Else
            Me.TopMost = True
            Button5.BackColor = Color.White
        End If
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        '########################################################################################
        '#####################   Show elements for download and trim video  #####################
        '########################################################################################

        GroupBox2.Text = "Step 2: Add a youtube - video link"     'add group titel
        'Button2.Text = "Download and Trim video"                                    'text of download button

        If TextBox1.Text = "" Or TextBox1.Text = "https://www.youtube.com/playlist?list=...  OR  https://www.youtube.com/watch?v=..." Then
            TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id"
            TextBox1.ForeColor = Color.Gray
        End If

        Label8.Text = "fps:"
        ComboBox3.Visible = False
        Label7.Visible = True
        Label8.Visible = True
        ComboBox1.Visible = True
        TextBox4.Visible = True
        GroupBox3.Visible = True

        Me.Height = 350

        GroupBox4.Visible = True                                                    'make Trim elements invisible

        '----------- Combobox Format --------------
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("mp4")
        ComboBox1.Items.Add("flv")
        ComboBox1.Items.Add("ogg")
        ComboBox1.Items.Add("webm")
        ComboBox1.Items.Add("mkv")
        ComboBox1.Items.Add("avi")
        ComboBox1.Items.Add("")

        ComboBox1.SelectedItem = ""
        '----------- Combobox youtube-Quality --------------
        ComboBox2.Items.Clear()
        ComboBox2.Items.Add("bestvideo+bestaudio")

        ComboBox2.SelectedItem = "bestvideo+bestaudio"

        '----------- Change position and visibility of Groupbox6  --------------
        GroupBox3.Visible = True
        GroupBox6.Visible = False

        '----------- Change position and visibility of Buttons  --------------
        Button2.Visible = True
        Button15.Visible = False

        '----------- Save current Height ---------------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(1) = "" Then Lines(1) = Me.Height
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        '########################################################################################
        '#####################   Show elements for download and trim audio  #####################
        '########################################################################################

        GroupBox2.Text = "Step 2: Add a youtube - video link"                        'add group titel
        'Button2.Text = "Download and Trim audio"                                    'text of download button

        If TextBox1.Text = "" Or TextBox1.Text = "https://www.youtube.com/playlist?list=...  OR  https://www.youtube.com/watch?v=..." Then
            TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id"
            TextBox1.ForeColor = Color.Gray
        End If

        Label8.Text = "kbit/s:"
        ComboBox3.Visible = True
        TextBox4.Visible = False
        Label7.Visible = True
        Label8.Visible = True
        ComboBox1.Visible = True

        GroupBox3.Visible = True

        Me.Height = 350

        GroupBox4.Visible = True                                                    'make Trim elements invisible
        ''----------- Combobox Format --------------
        ComboBox1.Items.Clear()
        ComboBox1.Items.Add("mp3")
        ComboBox1.Items.Add("wav")
        ComboBox1.Items.Add("aac")
        ComboBox1.Items.Add("flac")
        ComboBox1.Items.Add("m4a")
        ComboBox1.Items.Add("ogg")
        ComboBox1.Items.Add("opus")
        ComboBox1.Items.Add("vorbis")
        ComboBox1.Items.Add("")

        ComboBox1.SelectedItem = ""
        '----------- Combobox youtube-Quality --------------
        ComboBox2.Items.Clear()
        ComboBox2.Items.Add("bestaudio")

        ComboBox2.SelectedItem = "bestaudio"

        ''----------- Combobox convert-Quality --------------
        'ComboBox3.Items.Clear()
        'ComboBox3.Items.Add("lossless")
        'ComboBox3.Items.Add("320")
        'ComboBox3.Items.Add("256")
        'ComboBox3.Items.Add("192")
        'ComboBox3.Items.Add("160")
        'ComboBox3.Items.Add("128")
        'ComboBox3.Items.Add("96")
        'ComboBox3.Items.Add("32")
        'ComboBox3.Items.Add("")

        'ComboBox3.SelectedItem = ""

        '----------- Change position and visibility of Groupbox6  --------------
        GroupBox3.Visible = True
        GroupBox6.Visible = False

        '----------- Change position and visibility of Buttons  --------------
        Button2.Visible = True
        Button15.Visible = False

        '----------- Save current Height ---------------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(1) = "" Then Lines(1) = Me.Height
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        '########################################################################################
        '###########################   Show elements for download video  ########################
        '########################################################################################

        GroupBox2.Text = "Step 2: Add a youtube - playlist link"                               'add group titel
        'Button2.Text = "Download video(s)"                                                 'text of download button

        If TextBox1.Text = "" Or TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id" Then
            TextBox1.Text = "https://www.youtube.com/playlist?list=...  OR  https://www.youtube.com/watch?v=..."
            TextBox1.ForeColor = Color.Gray
        End If

        'Label8.Text = "fps:"
        ComboBox3.Visible = False
        'TextBox4.Visible = True
        GroupBox3.Visible = False

        Me.Height = 350

        'GroupBox4.Visible = False                                                       'make Trim elements invisible
        ' ''----------- Combobox Format --------------
        ComboBox1.Items.Clear()
        'ComboBox1.Items.Add("mp4")
        'ComboBox1.Items.Add("flv")
        'ComboBox1.Items.Add("ogg")
        'ComboBox1.Items.Add("webm")
        'ComboBox1.Items.Add("mkv")
        'ComboBox1.Items.Add("avi")
        'ComboBox1.Items.Add("")

        'ComboBox1.SelectedItem = ""
        ''----------- Combobox youtube-Quality --------------
        ComboBox2.Items.Clear()
        'ComboBox2.Items.Add("bestvideo+bestaudio")

        'ComboBox2.SelectedItem = "bestvideo+bestaudio"

        '----------- Change position and visibility of Groupboxes  --------------
        GroupBox6.Left = 6
        GroupBox6.Top = 160

        GroupBox3.Visible = False
        GroupBox6.Visible = True
        ComboBox4.SelectedItem = "audios"

        '----------- Change position and visibility of Buttons  --------------
        Button15.Left = 532
        Button15.Top = 289
        Button2.Visible = False
        Button15.Visible = True

        CheckBox1.Checked = True                    ' thumbnail to cover

        '----------- Save current Height ---------------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(1) = "" Then Lines(1) = Me.Height
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        '########################################################################################
        '#########################   Show elements for download audio  ##########################
        '########################################################################################

        GroupBox2.Text = "Step 2: Add a youtube - live stream link"             'add group titel
        'Button2.Text = "Download audio(s)"                                    'text of download button
        'If TextBox1.Text = "" Or TextBox1.Text = "https://youtu.be/id?t=00" Then
        '    TextBox1.Text = "https://www.youtube.com/watch?v=id"
        '    TextBox1.ForeColor = Color.Gray
        'End If
        'Label8.Text = "kbit/s:"
        'ComboBox3.Visible = True
        'TextBox4.Visible = False

        Me.Height = 350

        GroupBox4.Visible = False                                                   'make Trim elements invisible
        ''----------- Combobox Format --------------
        'ComboBox1.Items.Clear()
        'ComboBox1.Items.Add("mp3")
        'ComboBox1.Items.Add("wav")
        'ComboBox1.Items.Add("aac")
        'ComboBox1.Items.Add("flac")
        'ComboBox1.Items.Add("m4a")
        'ComboBox1.Items.Add("opus")
        'ComboBox1.Items.Add("vorbis")
        'ComboBox1.Items.Add("")

        'ComboBox1.SelectedItem = ""
        ''----------- Combobox youtube-Quality --------------
        ComboBox2.Items.Clear()
        ComboBox2.Items.Add("best")

        ComboBox2.SelectedItem = "best"

        ''----------- Combobox convert-Quality --------------
        'ComboBox3.Items.Clear()
        'ComboBox3.Items.Add("lossless")
        'ComboBox3.Items.Add("320")
        'ComboBox3.Items.Add("256")
        'ComboBox3.Items.Add("192")
        'ComboBox3.Items.Add("160")
        'ComboBox3.Items.Add("128")
        'ComboBox3.Items.Add("96")
        'ComboBox3.Items.Add("32")
        'ComboBox3.Items.Add("")

        'ComboBox3.SelectedItem = ""

        '----------- Change position and visibility of Groupboxes  --------------
        GroupBox3.Visible = True
        GroupBox6.Visible = False

        Label7.Visible = False
        Label8.Visible = False
        ComboBox1.Visible = False
        ComboBox3.Visible = False
        TextBox4.Visible = False

        '----------- Change position and visibility of Buttons  --------------
        Button15.Left = 532
        Button15.Top = 289
        Button2.Visible = False
        Button15.Visible = True

        '----------- Save current Height ---------------------------------------
        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(1) = "" Then Lines(1) = Me.Height
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)
    End Sub

    Private Sub TextBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.Click
        '########################################################################################
        '############################   Remove temp-links on click  #############################
        '########################################################################################
        If TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id" Then
            TextBox1.Text = ""
            TextBox1.ForeColor = Color.Black
        End If

        If TextBox1.Text = "https://www.youtube.com/playlist?list=...  OR  https://www.youtube.com/watch?v=..." Then
            TextBox1.Text = ""
            TextBox1.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '########################################################################################
        '######################   Set Height and path on program start  #########################
        '########################################################################################
        TextBox2.Text = Application.StartupPath
        Me.Height = 136

        '----------------------- create options file if not exist --------------
        If Not System.IO.File.Exists(Application.StartupPath & "\options.ini") Then                       'if options file not exist
            File.Create(Application.StartupPath & "\options.ini").Dispose()                               'create options file
            Dim createText() As String = {"", "", ""}                                           ' write empty lines in options file
            System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", createText)
        End If

        '---------------------- save new options ------------------------------

        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        If Lines(0) = "" Then Lines(0) = TextBox2.Text
        If Lines(0) <> "" Then TextBox2.Text = Lines(0)
        If Lines(1) <> "" Then Me.Height = Lines(1)
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        '########################################################################################
        '################################   Open output folder  #################################
        '########################################################################################
        Process.Start(TextBox2.Text)
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        '########################################################################################
        '###############################   Choose output folder  ################################
        '########################################################################################
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            TextBox2.Text = FolderBrowserDialog1.SelectedPath
        End If

        '----------- change options file --------------------

        Dim Lines() As String = System.IO.File.ReadAllLines(Application.StartupPath & "\options.ini")
        Lines(0) = TextBox2.Text
        System.IO.File.WriteAllLines(Application.StartupPath & "\options.ini", Lines)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        '########################################################################################
        '#####################   Check internet connection | Link   #############################
        '########################################################################################
        If My.Computer.Network.IsAvailable = False Then
            TextBox3.Text = "No internet connection available!"
            TextBox3.Visible = True
            Exit Sub
        End If

        'If TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id" Or TextBox1.Text = "" Then
        '    TextBox3.Text = "No youtube-link found!"
        '    TextBox3.Visible = True
        '    Exit Sub
        'End If
        '########################################################################################
        '############################   Stop youtube-dl or ffmpeg   #############################
        '########################################################################################
        For Each p As Process In Process.GetProcesses
            If p.ProcessName = "youtube-dl" Then

                Download_Process = New Process

                With Download_Process.StartInfo
                    .FileName = "cmd"
                    .RedirectStandardError = True
                    .RedirectStandardInput = True
                    .RedirectStandardOutput = True
                    .CreateNoWindow = True
                    .UseShellExecute = False
                End With

                Download_Process.Start()
                'Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
                Download_Process.StandardInput.WriteLine("taskkill /im youtube-dl.exe /t /f")
                Download_Process.StandardInput.WriteLine("exit")

                TextBox3.Text = "Process stoped"
                Button2.Text = "Start"                                       '"Start/Stop" button update

            End If

            If p.ProcessName = "ffmpeg" Then

                Download_Process = New Process

                With Download_Process.StartInfo
                    .FileName = "cmd"
                    .RedirectStandardError = True
                    .RedirectStandardInput = True
                    .RedirectStandardOutput = True
                    .CreateNoWindow = True
                    .UseShellExecute = False
                End With

                Download_Process.Start()
                'Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
                Download_Process.StandardInput.WriteLine("taskkill /im ffmpeg.exe /t /f")
                Download_Process.StandardInput.WriteLine("exit")

                TextBox3.Text = "Process stoped"
                Button2.Text = "Start"                                       '"Start/Stop" button update

                Exit Sub
            End If
        Next

        '########################################################################################
        '##########################   Read "start/end time"  for trim ###########################
        '########################################################################################
        Dim VarTimeStart As String = ""
        Dim VarTimeEnd As String = ""

        If GroupBox4.Visible = True Then

            Dim VarHoursStart As String
            Dim VarMinutesStart As String
            Dim VarSecondsStart As String
            Dim VarMillisecondsStart As String
            Dim VarHoursEnd As String
            Dim VarMinutesEnd As String
            Dim VarSecondsEnd As String
            Dim VarMillisecondsEnd As String

            If NumericUpDown1.Value < 10 Then
                VarHoursStart = "0" & NumericUpDown1.Value
            Else
                VarHoursStart = NumericUpDown1.Value
            End If

            If NumericUpDown2.Value < 10 Then
                VarMinutesStart = "0" & NumericUpDown2.Value
            Else
                VarMinutesStart = NumericUpDown2.Value
            End If

            If NumericUpDown3.Value < 10 Then
                VarSecondsStart = "0" & NumericUpDown3.Value
            Else
                VarSecondsStart = NumericUpDown3.Value
            End If

            If NumericUpDown7.Value < 10 Then
                VarMillisecondsStart = "00" & NumericUpDown7.Value
            ElseIf NumericUpDown7.Value > 9 And NumericUpDown7.Value < 100 Then
                VarMillisecondsStart = "0" & NumericUpDown7.Value
            Else
                VarMillisecondsStart = NumericUpDown7.Value
            End If

            '-----------------------
            If NumericUpDown6.Value < 10 Then
                VarHoursEnd = "0" & NumericUpDown6.Value
            Else
                VarHoursEnd = NumericUpDown6.Value
            End If

            If NumericUpDown5.Value < 10 Then
                VarMinutesEnd = "0" & NumericUpDown5.Value
            Else
                VarMinutesEnd = NumericUpDown5.Value
            End If

            If NumericUpDown4.Value < 10 Then
                VarSecondsEnd = "0" & NumericUpDown4.Value
            Else
                VarSecondsEnd = NumericUpDown4.Value
            End If

            If NumericUpDown8.Value < 10 Then
                VarMillisecondsEnd = "00" & NumericUpDown8.Value
            ElseIf NumericUpDown8.Value > 9 And NumericUpDown8.Value < 100 Then
                VarMillisecondsEnd = "0" & NumericUpDown8.Value
            Else
                VarMillisecondsEnd = NumericUpDown8.Value
            End If

            VarTimeStart = VarHoursStart & ":" & VarMinutesStart & ":" & VarSecondsStart & "." & VarMillisecondsStart
            VarTimeEnd = VarHoursEnd & ":" & VarMinutesEnd & ":" & VarSecondsEnd & "." & VarMillisecondsEnd

        End If

        '########################################################################################
        '############## Part of VIDEO-Link: Convert to format and choose video quality  #########
        '########################################################################################

        '########################################################################################
        '############## Part of AUDIO-Link: Convert to format and choose audio quality  #########
        '########################################################################################
        Dim ConvertVar As String = ""
        Dim ConvertVar2 As String = ""

        '----------- ConvertVar (if bestaudio has "m4a" format) | ConvertVar1 (if bestaudio has "webm" format)  -------------------
        If ComboBox1.SelectedItem = "mp3" Then                      'convert to mp3
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: choosed kbit/s
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "wav" Then
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " " & TextBox2.Text & "\output.wav" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " " & TextBox2.Text & "\output.wav" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: 
                'ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                'ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "aac" Then
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -c:a copy " & TextBox2.Text & "\output.aac" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -c:a copy " & TextBox2.Text & "\output.aac" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: 
                'ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                'ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "flac" Then
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -f flac " & TextBox2.Text & "\output.flac" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -f flac " & TextBox2.Text & "\output.flac" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: 
                'ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                'ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "m4a" Then
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -c copy " & TextBox2.Text & "\output.m4a" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -c copy " & TextBox2.Text & "\output.webm" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: 
                'ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                'ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "ogg" Then
            If ComboBox3.SelectedItem = "lossless" Then             'quality: best as possible
                ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " " & TextBox2.Text & "\output.ogg" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " " & TextBox2.Text & "\output.ogg" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            Else                                                    'quality: 
                'ConvertVar = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a"
                'ConvertVar2 = " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -acodec libmp3lame -ab " & ComboBox3.SelectedItem & "k " & TextBox2.Text & "\output.mp3" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm"
            End If
        ElseIf ComboBox1.SelectedItem = "opus" Then

        ElseIf ComboBox1.SelectedItem = "vorbis" Then

        End If

        '########################################################################################
        '#######################   Create download-trim video/audio link  #######################
        '########################################################################################

        Dim CMDcommand As String = ""

        If ComboBox2.Items(0) = "bestvideo+bestaudio" And VarTimeStart <> "00:00:00.000" And VarTimeEnd <> "00:00:00.000" Then           '####### Download video with youtube-dl and trim with ffmpeg

            If ComboBox2.Items(0) = "bestvideo+bestaudio" And ComboBox1.SelectedItem = "" Then                                       'download and trim video
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.%(ext)s " & TextBox1.Text & " && ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.mp4 -ss " & VarTimeStart & " -to " & VarTimeEnd & " -c copy " & TextBox2.Text & "\output.mp4" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.mp4" & " && echo done" & "||" & "ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm -ss " & VarTimeStart & " -to " & VarTimeEnd & " -c:v copy -c:a copy " & TextBox2.Text & "\output.webm" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " && echo done" & "||" & "ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.mkv -ss " & VarTimeStart & " -to " & VarTimeEnd & " -c:v copy -c:a copy " & TextBox2.Text & "\output.mkv" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.mkv" & " && echo done"
            Else                                                                                                                'download, trim and convert video
                'CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " " & "--output  " & TextBox2.Text & "\%(title)s.%(ext)s " & TextBox1.Text
            End If

        ElseIf ComboBox2.Items(0) = "bestvideo+bestaudio" And VarTimeStart = "00:00:00.000" And VarTimeEnd = "00:00:00.000" Then         '####### Download video

            If ComboBox2.Items(0) = "bestvideo+bestaudio" And ComboBox1.SelectedItem = "" Then                                       'download video
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & TextBox2.Text & "\%(title)s.%(ext)s " & TextBox1.Text & " && echo done"
            Else                                                                                                                'download video and convert to ...
                'CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " " & "--output  " & TextBox2.Text & "\%(title)s.%(ext)s " & TextBox1.Text & " && echo done"
            End If

        ElseIf ComboBox2.Items(0) = "bestaudio" And VarTimeStart <> "00:00:00.000" And VarTimeEnd <> "00:00:00.000" Then       '####### Download audio with youtube-dl and trim with ffmpeg

            If ComboBox2.Items(0) = "bestaudio" And ComboBox1.SelectedItem = "" Then                                       'download and trim audio
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.%(ext)s " & TextBox1.Text & " && ffmpeg -ss " & VarTimeStart & " -to " & VarTimeEnd & " -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a -acodec copy " & TextBox2.Text & "\output.m4a" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & " && echo done" & "||" & "ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " -ss " & VarTimeStart & " -to " & VarTimeEnd & " -c:v libvpx -c:a copy " & TextBox2.Text & "\output.webm" & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & " && echo done"
            Else                                                                                                                'download, trim and convert audio
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp0.%(ext)s " & TextBox1.Text & " && ffmpeg -ss " & VarTimeStart & " -to " & VarTimeEnd & " -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp0.m4a -acodec copy " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.m4a" & ConvertVar & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp0.m4a" & " && echo done" & "||" & "ffmpeg -i " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp0.webm" & " -ss " & VarTimeStart & " -to " & VarTimeEnd & " -c:v libvpx -c:a copy " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.webm" & ConvertVar2 & " && del /f " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp0.webm" & " && echo done"
            End If

        ElseIf ComboBox2.Items(0) = "bestaudio" And VarTimeStart = "00:00:00.000" And VarTimeEnd = "00:00:00.000" Then         '####### Download audio

            If ComboBox2.Items(0) = "bestaudio" And ComboBox1.SelectedItem = "" Then                                       'download audio
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & TextBox2.Text & "\%(title)s.%(ext)s " & TextBox1.Text & " && echo done"
            Else                                                                                                                'download audio and convert to ...
                CMDcommand = "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.%(ext)s " & TextBox1.Text & ConvertVar & " && echo done" & "||" & "youtube-dl -f " & ComboBox2.SelectedItem & " --output  " & Application.StartupPath & "\youtube-dl-ffmpeg" & "\temp.%(ext)s " & TextBox1.Text & ConvertVar2 & " && echo done"
            End If

        End If

        '########################################################################################
        '##############################   Download video/audio ##################################
        '########################################################################################
        Button2.Text = "Stop"                                       '"Download" button update
        Button2.Refresh()

        TextBox3.Visible = True                                     '"Status" fiel update
        TextBox3.Text = "Download started"
        TextBox3.Refresh()

        Download_Process = New Process

        With Download_Process.StartInfo
            .FileName = "cmd"
            .RedirectStandardError = True
            .RedirectStandardInput = True
            .RedirectStandardOutput = True
            .CreateNoWindow = True
            .UseShellExecute = False
        End With

        Download_Process.Start()
        Download_Process.StandardInput.WriteLine("chcp 1251")
        Download_Process.StandardInput.WriteLine("cls")
        Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
        Download_Process.StandardInput.WriteLine(CMDcommand)
        'Download_Process.StandardInput.WriteLine("exit")

        Download_Process.BeginErrorReadLine()
        Download_Process.BeginOutputReadLine()
    End Sub

    Private Sub p_OutputDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Download_Process.OutputDataReceived
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub p_ErrorDataReceived(ByVal sender As Object, ByVal e As DataReceivedEventArgs) Handles Download_Process.ErrorDataReceived
        Me.Invoke(New WriteA(AddressOf Write), e.Data & Environment.NewLine)
    End Sub

    Private Sub Write(ByVal Line As String)
        '########################################################################################
        '#######################   Status line (textfield) update  ##############################
        '########################################################################################

        If Line.Contains("[youtube]") Or Line.Contains("[download]") Or Line.Contains("[ffmpeg]") Or Line.Contains("time=") Or Line.Contains("frame=") Then
            TextBox3.Text = Line
            'TextBox3.SelectionStart = TextBox3.Text.Length
        End If

        If Line.Contains("MiB in") Then
            TextBox3.Text = "Download finished"
        ElseIf Line.Contains(">exit") Then
            TextBox3.Text = "All done"
            Button2.Text = "Start"                                       '"Start/Stop" button update
            Button2.Refresh()
            Button15.Text = "Start"                                       '"Start/Stop" button update
            Button15.Refresh()
        ElseIf Line.Contains("done") Then
            If Line.Contains("echo done") Then GoTo here
            TextBox3.Text = "All done"
            Button2.Text = "Start"                                       '"Start/Stop" button update
            Button2.Refresh()
            Button15.Text = "Start"                                       '"Start/Stop" button update
            Button15.Refresh()
here:
        End If

    End Sub
    Private WithEvents Download_Process As Process
    Private Delegate Sub WriteA(ByVal Text As String)
    Private Sub ComboBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox1.SelectedIndexChanged
        '########################################################################################
        '####################   Combobox make empty | Combobox format change  ###################
        '########################################################################################
        If ComboBox1.SelectedItem = "" Then
            ComboBox3.SelectedItem = ""
            ComboBox3.Items.Clear()
        End If

        If ComboBox1.SelectedItem = "mp3" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            ComboBox3.Items.Add("320")
            ComboBox3.Items.Add("256")
            ComboBox3.Items.Add("192")
            ComboBox3.Items.Add("160")
            ComboBox3.Items.Add("128")
            ComboBox3.Items.Add("96")
            ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "wav" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            'ComboBox3.Items.Add("320")
            'ComboBox3.Items.Add("256")
            'ComboBox3.Items.Add("192")
            'ComboBox3.Items.Add("160")
            'ComboBox3.Items.Add("128")
            'ComboBox3.Items.Add("96")
            'ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "aac" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            'ComboBox3.Items.Add("320")
            'ComboBox3.Items.Add("256")
            'ComboBox3.Items.Add("192")
            'ComboBox3.Items.Add("160")
            'ComboBox3.Items.Add("128")
            'ComboBox3.Items.Add("96")
            'ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "flac" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            'ComboBox3.Items.Add("320")
            'ComboBox3.Items.Add("256")
            'ComboBox3.Items.Add("192")
            'ComboBox3.Items.Add("160")
            'ComboBox3.Items.Add("128")
            'ComboBox3.Items.Add("96")
            'ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "m4a" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            'ComboBox3.Items.Add("320")
            'ComboBox3.Items.Add("256")
            'ComboBox3.Items.Add("192")
            'ComboBox3.Items.Add("160")
            'ComboBox3.Items.Add("128")
            'ComboBox3.Items.Add("96")
            'ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "ogg" Then
            '----------- Combobox convert-Quality --------------
            ComboBox3.Items.Clear()
            ComboBox3.Items.Add("lossless")
            'ComboBox3.Items.Add("320")
            'ComboBox3.Items.Add("256")
            'ComboBox3.Items.Add("192")
            'ComboBox3.Items.Add("160")
            'ComboBox3.Items.Add("128")
            'ComboBox3.Items.Add("96")
            'ComboBox3.Items.Add("32")
            ComboBox3.Items.Add("")
        End If

        If ComboBox1.SelectedItem = "mp3" Or ComboBox1.SelectedItem = "wav" Or ComboBox1.SelectedItem = "aac" Or ComboBox1.SelectedItem = "flac" Or ComboBox1.SelectedItem = "m4a" Or ComboBox1.SelectedItem = "ogg" Or ComboBox1.SelectedItem = "opus" Or ComboBox1.SelectedItem = "vorbis" Then ComboBox3.SelectedItem = "lossless"

    End Sub

    Private Sub ComboBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ComboBox3.SelectedIndexChanged
        '########################################################################################
        '##############################   Combobox make empty  ##################################
        '########################################################################################
        If ComboBox3.SelectedItem = "" Then ComboBox1.SelectedItem = ""
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        '########################################################################################
        '############   Clear Textbox (Link) | Paste Link from clipboard to textbox  ############
        '########################################################################################
        TextBox1.Text = ""
        Me.TextBox1.Paste()
        TextBox1.ForeColor = Color.Black
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        '########################################################################################
        '####################   Check if "qualities" window is already opened  ##################
        '########################################################################################
        For Each frm As Form In Application.OpenForms
            If frm.Name.Equals("Quality") Then          'if opened , close!
                Quality.Show()
                Quality.Close()
                Exit For
            End If
        Next

        '########################################################################################
        '################################   Open "qualities" window #############################
        '########################################################################################
        TextBox3.Text = ""
        If TextBox1.Text.Contains("https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id") Then
            TextBox3.Text = "No youtube-link found!"
            TextBox3.Visible = True
            Exit Sub
        ElseIf TextBox1.Text.Contains("youtu") Then
            Quality.Show()
        Else
            TextBox3.Text = "No youtube-link found!"
            TextBox3.Visible = True
            Exit Sub
        End If

    End Sub

    '################################################################################################################################################################################
    '########################################################   Playlist download ###################################################################################################
    '################################################################################################################################################################################

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        '########################################################################################
        '################################   Enable/Diseble "Sort" Elements ######################
        '########################################################################################

        If Label12.Enabled = False Then
            Label11.Enabled = False
            TextBox5.Enabled = False

            Label12.Enabled = True
            NumericUpDown9.Enabled = True
            NumericUpDown10.Enabled = True

        ElseIf Label12.Enabled = True Then
            Label11.Enabled = True
            TextBox5.Enabled = True

            Label12.Enabled = False
            NumericUpDown9.Enabled = False
            NumericUpDown10.Enabled = False
        End If

    End Sub

    Private Sub TextBox5_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.Click
        '########################################################################################
        '############################   Remove example items on click  ##########################
        '########################################################################################
        If TextBox5.Text = "example: 1-3,7,8,10-13" Then
            TextBox5.Text = ""
            TextBox5.ForeColor = Color.Black
        End If
    End Sub

    Private Sub TextBox6_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.Click
        '########################################################################################
        '############################   Remove example title on click  ##########################
        '########################################################################################
        If TextBox6.Text = "example: Chuck Berry" Then
            TextBox6.Text = ""
            TextBox6.ForeColor = Color.Black
        End If
    End Sub

    Private Sub TextBox7_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.Click
        '########################################################################################
        '############################   Remove example title on click  ##########################
        '########################################################################################
        If TextBox7.Text = "example: Johnny B Goode" Then
            TextBox7.Text = ""
            TextBox7.ForeColor = Color.Black
        End If
    End Sub

    Private Sub Button15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button15.Click
        '########################################################################################
        '#####################   Check internet connection | Link   #############################
        '########################################################################################
        If My.Computer.Network.IsAvailable = False Then
            TextBox3.Text = "No internet connection available!"
            TextBox3.Visible = True
            Exit Sub
        End If

        'If TextBox1.Text = "https://youtu.be/id?t=00  OR  https://www.youtube.com/watch?v=id" Or TextBox1.Text = "" Then
        '    TextBox3.Text = "No youtube-link found!"
        '    TextBox3.Visible = True
        '    Exit Sub
        'End If
        '########################################################################################
        '############################   Stop youtube-dl or ffmpeg   #############################
        '########################################################################################
        Dim Temp As String = ""
        For Each p As Process In Process.GetProcesses

            If p.ProcessName = "youtube-dl" Or p.ProcessName = "ffmpeg" Then

                If GroupBox6.Visible = False Then                         'stop recording live stream

                    '########## Show cmd
                    Dim intptrs() As IntPtr = MyCMDProcess.ToArray
                    For i = 0 To intptrs.Length - 1
                        If ShowWindow(intptrs(i), ShowWindowCommands.ShowDefault) Then
                            MyCMDProcess.Remove(intptrs(i))
                        End If
                    Next
                    '###### set cmd as Main Front Window

                    Dim MyCMD = Process.GetProcessesByName("cmd")
                    If MyCMD.Count = 0 Then
                    Else
                        SetWindowPos(MyCMD.First.MainWindowHandle, New IntPtr(hWndInsertAfter.BehindTopMost), -1, -1, -1, -1, uFlags.SWP_NOMOVE Or uFlags.SWP_NOSIZE Or uFlags.SWP_SHOWWINDOW)
                        SendKeys.Send("^{C}")
                    End If

                    '###### Hide cmd
                    For Each pp As Process In Process.GetProcessesByName("cmd")
                        If ShowWindow(pp.MainWindowHandle, ShowWindowCommands.Hide) Then
                            MyCMDProcess.Add(pp.MainWindowHandle)
                        End If
                    Next

                    Download_Process.StandardInput.WriteLine("taskkill /im cmd.exe /t /f")
                    Exit Sub
                End If

                Temp = 1
                Download_Process = New Process

                With Download_Process.StartInfo
                    .FileName = "cmd"
                    .RedirectStandardError = True
                    .RedirectStandardInput = True
                    .RedirectStandardOutput = True
                    .CreateNoWindow = True
                    .UseShellExecute = False
                End With

                Download_Process.Start()
                'Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
                Download_Process.StandardInput.WriteLine("taskkill /im youtube-dl.exe /t /f")
                Download_Process.StandardInput.WriteLine("taskkill /im ffmpeg.exe /t /f")
                Download_Process.StandardInput.WriteLine("exit")

                TextBox3.Text = "Process stoped"
                Button15.Text = "Start"                                       '"Start/Stop" button update

            End If
        Next
        If Temp = "1" Then Exit Sub

        '########################################################################################
        '######################   Create playlist cmd-command to download  ######################
        '########################################################################################

        Dim FullPlaylistLink As String = ""
        On Error Resume Next

        If TextBox1.Text.Contains("https://www.youtube.com/playlist?list=") Then
            FullPlaylistLink = TextBox1.Text
        Else
            FullPlaylistLink = TextBox1.Text.Replace(Strings.Left(TextBox1.Text, InStr(TextBox1.Text, "=")), "")

            Do While FullPlaylistLink.Contains("=")
                FullPlaylistLink = FullPlaylistLink.Replace(Strings.Left(FullPlaylistLink, InStr(FullPlaylistLink, "=")), "")
            Loop

            FullPlaylistLink = "https://www.youtube.com/playlist?list=" & FullPlaylistLink
        End If

        If FullPlaylistLink = "https://www.youtube.com/playlist?list=" Or TextBox1.Text = "https://www.youtube.com/playlist?list=...  OR  https://www.youtube.com/watch?v=..." Or TextBox1.Text = "" Then
            TextBox3.Visible = True
            TextBox3.Text = "Wrong playlist link"
            Exit Sub
        End If

        '########################################################################################
        '########################   Create part of cmd-command (playlist)########################
        '########################################################################################
        Dim SortTitles As String = ""

        If Label11.Enabled = True Then

            If TextBox5.Text = "example: 1-3,7,8,10-13" Or TextBox5.Text = "" Then
                SortTitles = ""
            Else
                SortTitles = "--playlist-items " & TextBox5.Text
            End If

        ElseIf Label12.Enabled = True Then

            If NumericUpDown10.Value > NumericUpDown9.Value Then
                SortTitles = "--playlist-start " & NumericUpDown9.Value
                SortTitles = SortTitles & " --playlist-end " & NumericUpDown10.Value
            End If

        End If

        If TextBox6.Text <> "example: Chuck Berry" Or TextBox6.Text = "" Then
            SortTitles = SortTitles & " --match-title " & TextBox6.Text
        End If

        If TextBox7.Text <> "example: Johnny B Goode" Or TextBox7.Text = "" Then
            SortTitles = SortTitles & " --reject-title " & TextBox7.Text
        End If

        If NumericUpDown11.Value > "0" Then
            SortTitles = SortTitles & " --age-limit " & NumericUpDown11.Value
        End If

        Dim DownloadClips As String = ""
        Dim DownloadTracks1 As String = ""
        Dim DownloadTracks2 As String = ""
        If ComboBox4.SelectedItem = "videos" Then
            DownloadClips = "-f bestvideo+bestaudio "
        End If
        If ComboBox4.SelectedItem = "audios" Then
            DownloadTracks1 = " -f bestaudio "
            DownloadTracks2 = " --extract-audio --audio-format mp3 "
        End If

        Dim CoverVar As String = ""
        If CheckBox1.Checked = True And ComboBox4.SelectedItem = "audios" Then
            CoverVar = " --embed-thumbnail "
        End If

        '########################################################################################
        '#####################   Create full cmd-command  for playlist ##########################
        '########################################################################################
        Dim CMDcommand As String = ""
        CMDcommand = "youtube-dl --ignore-errors " & DownloadTracks1 & DownloadClips & CoverVar & SortTitles & DownloadTracks2 & " --output  " & TextBox2.Text & "\%(title)s.%(ext)s " & FullPlaylistLink & " && echo done"

        '########################################################################################
        '###################   Create full cmd-command  for live stream #########################
        '########################################################################################
        If GroupBox6.Visible = False Then
            CMDcommand = "youtube-dl -i -f " & ComboBox2.SelectedItem & " --output  " & TextBox2.Text & "\%(title)s.%(ext)s " & TextBox1.Text & " && echo done"
        End If
        'MsgBox(CMDcommand)
        'Exit Sub
        '########################################################################################
        '##############################   Download video/audio ##################################
        '########################################################################################
        Button15.Text = "Stop"                                       '"Start/Stop" button update
        Button15.Refresh()

        TextBox3.Visible = True                                     '"Status" fiel update
        TextBox3.Text = "Download started"
        TextBox3.Refresh()

        Download_Process = New Process

        With Download_Process.StartInfo
            .FileName = "cmd"
            .RedirectStandardError = True
            .RedirectStandardInput = True
            .RedirectStandardOutput = True

            If GroupBox6.Visible = False Then               'if live stream record
                .CreateNoWindow = False
            Else
                .CreateNoWindow = True                      'if playlist download
            End If

            .UseShellExecute = False
        End With

        Download_Process.Start()
        Download_Process.StandardInput.WriteLine("chcp 1251")
        Download_Process.StandardInput.WriteLine("cls")
        Download_Process.StandardInput.WriteLine("cd " & Application.StartupPath & "\youtube-dl-ffmpeg")
        Download_Process.StandardInput.WriteLine(CMDcommand)
        'Download_Process.StandardInput.WriteLine("exit")

        Download_Process.BeginErrorReadLine()
        Download_Process.BeginOutputReadLine()

        '------ waiting for creating "cmd" ------ 
        If GroupBox6.Visible = False Then
            Dim Time As Integer = 0
            Do
                For Each pp As Process In Process.GetProcessesByName("cmd")
                    If ShowWindow(pp.MainWindowHandle, ShowWindowCommands.Hide) Then
                        MyCMDProcess.Add(pp.MainWindowHandle)
                        Time = 1
                    End If
                Next
            Loop While (Time = 0)
        End If
    End Sub

    '################################################################################################################################################################################
    '########################################################  add DLLs for Live stream download ################################################################################################
    '################################################################################################################################################################################

    '--------------------------  set cmd window in Foreground -----------------------------
    <System.Runtime.InteropServices.DllImport("user32.dll", SetLastError:=True)> _
    Public Shared Function SetWindowPos(ByVal hWnd As IntPtr, ByVal hWndInsertAfter As IntPtr, ByVal X As Integer, ByVal Y As Integer, ByVal cx As Integer, ByVal cy As Integer, ByVal uFlags As UInteger) As Boolean
    End Function
    Enum uFlags As UInteger
        SWP_NOMOVE = &H2
        SWP_NOSIZE = &H1
        SWP_SHOWWINDOW = &H40
    End Enum
    Enum hWndInsertAfter As Integer
        BehindTopMost = -2
    End Enum

    '####################################

    Private MyCMDProcess As New List(Of IntPtr)

    <DllImport("user32.dll", SetLastError:=True, CharSet:=CharSet.Auto)> _
    Private Shared Function ShowWindow(ByVal hWnd As IntPtr, ByVal nCmdShow As ShowWindowCommands) As Boolean
    End Function

    Enum ShowWindowCommands As Integer
        Hide = 0
        Normal = 1
        ShowMinimized = 2
        Maximize = 3
        ShowMaximized = 3
        ShowNoActivate = 4
        Show = 5
        Minimize = 6
        ShowMinNoActive = 7
        ShowNA = 8
        Restore = 9
        ShowDefault = 10
        ForceMinimize = 11
    End Enum

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        About.Show()
    End Sub

End Class
